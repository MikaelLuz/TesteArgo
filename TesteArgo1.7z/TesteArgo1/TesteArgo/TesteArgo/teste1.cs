﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace TesteArgo
{
    
    public class teste1
    {
        int acumulado=0;
        decimal media=0;
        

        /*Método para somar 2 números*/
        public int Somar(int n1, int n2)
        {
            return n1 + n2; ;
        }

        /*Método para subtrair 2 números*/
        public int Subtrair(int n1, int n2)
        {
            return n1-n2;
        }
        
        /*Método para somar números e calcular a média*/
        public decimal Media(params int[] valores)
        {
            media = 0;
            acumulado = 0;
            
            for (int i = 0; i < valores.Length; i++ )
            {
                acumulado += valores[i];                               
            }

            media = acumulado / valores.Length;
            return media;
            
        }

        /*Método para calcular a idade*/
        public int CalcularIdade(int ano, int mes, int dia)
        {
            
            int idade = DateTime.Now.Year - ano;
            if (DateTime.Now.Month < mes || 
               (DateTime.Now.Month == mes && 
                DateTime.Now.Day < dia))
                idade--;

            return idade;

        }
    }
}
