﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TesteArgo
{
    public class teste2
    {
        public List<int> CriarLista(int quantidade)
        {
            List<int> lista = new List<int>();
            for (int i = 0; i < 500; i++)
            {
                lista.Add(i);
            }
            return lista;

        }

        public List<int> OrdenarLista(params int[] valores)
        {
            List<int> list = new List<int>(new int[] { 8, 9, 6, 5, 6, 4, 3, 25, 89 });

        for(int i=0; i<list.Count; i++)
            {
                Console.WriteLine($"{i} = {list[i]}");
            }
            return list;
        }
        
    }
}
