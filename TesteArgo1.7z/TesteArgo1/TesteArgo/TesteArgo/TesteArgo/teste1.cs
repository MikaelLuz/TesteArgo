﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TesteArgo
{
    public class teste1
    {
        public int Somar(int n1, int n2)
        {
            return 0;
        }

        public int Subtrair(int n1, int n2)
        {
            return 0;
        }

        public decimal Media(params int[] valores)
        {
            return 0;
        }

        public int CalcularIdade(int ano, int mes, int dia)
        {
            return 0;
        }
    }
}
